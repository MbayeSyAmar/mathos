// ============================================
// SCRIPT POUR COPIER LES PDFs VERS LE DOSSIER mathos/pdfs/
// ============================================

const fs = require('fs');
const path = require('path');

const sourceDir = path.join(__dirname, '../../RESSOURCES MATHOSPHERE');
const targetDir = path.join(__dirname, '../pdfs');

// Créer la structure de dossiers cible
const structure = {
  'exercices': {
    '2nde': [],
    '1ere': [],
    'terminale': []
  }
};

// Mapping des fichiers PDF vers les dossiers cibles
const pdfMapping = {
  // Exercices 2nde
  'Exercice 2nd S/Fonctions.pdf': 'exercices/2nde/fonctions.pdf',
  'Exercice 2nd S/Calcul vectoriel.pdf': 'exercices/2nde/calcul-vectoriel.pdf',
  'Exercice 2nd S/Angles.pdf': 'exercices/2nde/angles.pdf',
  'Exercice 2nd S/Barycentre.pdf': 'exercices/2nde/barycentre.pdf',
  'Exercice 2nd S/Calcul dans R.pdf': 'exercices/2nde/calcul-dans-r.pdf',
  'Exercice 2nd S/Polynomes.pdf': 'exercices/2nde/polynomes.pdf',
  'Exercice 2nd S/Second degrés.pdf': 'exercices/2nde/second-degre.pdf',
  'Exercice 2nd S/systemes.pdf': 'exercices/2nde/systemes.pdf',
  
  // Exercices 1ère
  'Exercice 1S1/Dérivées.pdf': 'exercices/1ere/derivees.pdf',
  'Exercice 1S1/Suites numériques.pdf': 'exercices/1ere/suites-numeriques.pdf',
  'Exercice 1S1/Angles orienté.pdf': 'exercices/1ere/angles-orientes.pdf',
  'Exercice 1S1/Dénombrement.pdf': 'exercices/1ere/denombrement.pdf',
  'Exercice 1S1/Equations, inéquations et systèmes.pdf': 'exercices/1ere/equations-inequations-systemes.pdf',
  'Exercice 1S1/Fonctions.pdf': 'exercices/1ere/fonctions.pdf',
  'Exercice 1S1/Identités et relations trigonométriques.pdf': 'exercices/1ere/identites-trigonometriques.pdf',
  'Exercice 1S1/Limites et Continuité.pdf': 'exercices/1ere/limites-continuite.pdf',
  'Exercice 1S1/Primitives.pdf': 'exercices/1ere/primitives.pdf',
  'Exercice 1S1/Transformations du plan.pdf': 'exercices/1ere/transformations-plan.pdf',
  
  // Exercices Terminale S1
  'Exercice TS1/calcul_integral.pdf': 'exercices/terminale/calcul-integral.pdf',
  'Exercice TS1/Nombre_complexe.pdf': 'exercices/terminale/nombres-complexes.pdf',
  'Exercice TS1/Probabilités.pdf': 'exercices/terminale/probabilites.pdf',
  'Exercice TS1/Arithmetique.pdf': 'exercices/terminale/arithmetique.pdf',
  'Exercice TS1/DERIVATION_TS1.pdf': 'exercices/terminale/derivation.pdf',
  'Exercice TS1/equations_differentielles.pdf': 'exercices/terminale/equations-differentielles.pdf',
  'Exercice TS1/FONCTIONS_EXPO_LN_TS1.pdf': 'exercices/terminale/fonctions-expo-ln.pdf',
  'Exercice TS1/Limites_et_continuité.pdf': 'exercices/terminale/limites-continuite.pdf',
  'Exercice TS1/Suites_ts1.pdf': 'exercices/terminale/suites-numeriques.pdf',
  
  // Exercices Terminale S2
  'Exercice TS2/CALCUL INTEGRAL.pdf': 'exercices/terminale/calcul-integral-s2.pdf',
  'Exercice TS2/EQUATIONS DIFFERENTIELLES.pdf': 'exercices/terminale/equations-differentielles-s2.pdf',
  'Exercice TS2/FONCTIONS NUMERIQUES.pdf': 'exercices/terminale/fonctions-numeriques.pdf',
  'Exercice TS2/NOMBRES COMPLEXES ET SIMILITUDES.pdf': 'exercices/terminale/nombres-complexes-similitudes.pdf',
  'Exercice TS2/PROBABLITES.pdf': 'exercices/terminale/probabilites-s2.pdf',
  'Exercice TS2/PROBLEME DE SYNTHESE.pdf': 'exercices/terminale/probleme-synthese.pdf',
  'Exercice TS2/STATISTIQUES.pdf': 'exercices/terminale/statistiques.pdf',
  'Exercice TS2/SUITES NUMERIQUES.pdf': 'exercices/terminale/suites-numeriques-s2.pdf'
};

function copyPDFs() {
  console.log('📁 Création de la structure de dossiers...');
  
  // Créer les dossiers nécessaires
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  
  ['exercices/2nde', 'exercices/1ere', 'exercices/terminale'].forEach(dir => {
    const fullPath = path.join(targetDir, dir);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
      console.log(`✅ Dossier créé: ${dir}`);
    }
  });
  
  console.log('\n📄 Copie des fichiers PDF...');
  let copied = 0;
  let errors = 0;
  
  Object.entries(pdfMapping).forEach(([source, target]) => {
    const sourcePath = path.join(sourceDir, source);
    const targetPath = path.join(targetDir, target);
    
    try {
      if (fs.existsSync(sourcePath)) {
        // Créer le dossier parent si nécessaire
        const targetParent = path.dirname(targetPath);
        if (!fs.existsSync(targetParent)) {
          fs.mkdirSync(targetParent, { recursive: true });
        }
        
        fs.copyFileSync(sourcePath, targetPath);
        console.log(`✅ ${source} → ${target}`);
        copied++;
      } else {
        console.log(`⚠️  Fichier non trouvé: ${source}`);
        errors++;
      }
    } catch (error) {
      console.error(`❌ Erreur lors de la copie de ${source}:`, error.message);
      errors++;
    }
  });
  
  console.log(`\n✨ Terminé ! ${copied} fichiers copiés, ${errors} erreurs`);
}

// Exécuter le script
if (require.main === module) {
  copyPDFs();
}

module.exports = { copyPDFs };

