import type { NextConfig } from "next";

const nextConfig = {
  // output: 'export',
  images: { unoptimized: true },
  // basePath: '/mathos', // Remplace par le nom de ton repo GitHub
  // assetPrefix: '/mathos/',
};

export default nextConfig;
